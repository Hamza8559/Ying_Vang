
<section class="footerBG">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 fotCol">
                <div class="fotLinks">
                    <h4>Our community</h4>
                    <span class="footBorder"></span>
                    <ul>
                        <li><a href="">list item #1</a></li>
                        <li><a href="">list item #1</a></li>
                        <li><a href="">list item #1</a></li>
                        <li><a href="">list item #1</a></li>
                        <li><a href="">list item #1</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 fotCol">
                <div class="fotLinks">
                    <h4>About armadon</h4>
                    <span class="footBorder"></span>
                    <ul>
                        <li><a href="">News</a></li>
                        <li><a href="">Teams</a></li>
                        <li><a href="">Partners</a></li>
                        <li><a href="">Knowledge base</a></li>
                        <li><a href="">Base our team</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 fotCol">
                <div class="fotLinks">
                    <h4>About armadon</h4>
                    <span class="footBorder"></span>
                    <ul>
                        <li><a href=""><i class="fa-brands fa-square-facebook"></i> Your name</a></li>
                        <li><a href=""><i class="fa-brands fa-youtube"></i> Channal</a></li>
                        <li><a href=""><i class="fa-brands fa-rocketchat"></i> Live Platform</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-5">
            <div class="col-lg-8">
                <div class="fotLinks fotLogo">
                    <h4>Your Logo</h4>
                    <ul>
                        <li><a href="">© <?php echo date("Y");?> Copyright Reserved.</a></li>
                    </ul>
                    <ul class="scdUlCopy">
                        <li><a href="">privacy policy</a></li>
                        <li><a href="">terms of services</a></li>
                        <li><a href="">register</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/3.0.1/jquery-migrate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.js"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script src="./assets/js/all.min.js"></script>
<script src="./assets/js/main.js"></script>
