<a class="topToBtn">
   <i class="fa-solid fa-arrow-up-long"></i>
</a>